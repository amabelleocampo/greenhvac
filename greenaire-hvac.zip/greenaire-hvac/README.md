# GreenAire HVAC — Lead Generation Website

A modern, mobile-responsive lead generation website for a minority-owned green energy HVAC startup. Built with pure HTML, CSS, and JavaScript — no frameworks or build tools required.

---

## 📁 Project Structure

```
greenaire-hvac/
├── public/
│   └── index.html          # Main website (self-contained)
├── src/
│   └── site-config.json    # Full site content & config
├── .gitignore
├── README.md
└── package.json            # Optional: for local dev server
```

---

## 🚀 Quick Start

### Option 1 — Open directly in browser
```bash
open public/index.html
```

### Option 2 — Run a local dev server
```bash
npm install
npm start
# Visit http://localhost:3000
```

### Option 3 — Deploy to Netlify / Vercel
Drag and drop the `public/` folder into [Netlify Drop](https://app.netlify.com/drop) for instant hosting.

---

## ✏️ Customization

All site content lives in `src/site-config.json`. Update:

| Key | What it controls |
|-----|-----------------|
| `site.name` | Business name |
| `site.phone` | Contact phone number |
| `branding.colors` | Full color palette |
| `services.items` | Service cards |
| `testimonials.items` | Customer reviews |
| `leadForm.form.fields` | Contact form fields |
| `serviceAreas.cities` | Cities served |
| `seo` | Meta title, description, keywords |

> **Note:** The HTML file is currently self-contained. To make it data-driven from the JSON config, integrate with a framework like React/Next.js or use a simple JS fetch on load.

---

## 🔌 Connecting the Lead Form

The form currently shows a success message on submit. To connect it to a real backend:

### Formspree (easiest — free tier available)
1. Sign up at [formspree.io](https://formspree.io)
2. Create a form and get your endpoint URL
3. In `index.html`, update the form tag:
```html
<form action="https://formspree.io/f/YOUR_ID" method="POST">
```

### HubSpot / Salesforce / Mailchimp
Replace the `submitForm()` function in `index.html` with a `fetch()` POST to your CRM's API endpoint.

### EmailJS (no backend needed)
```js
emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', form);
```

---

## 💰 Tax Credit Info (for content updates)

- **Federal IRA Credit:** 30% of heat pump installation cost (up to $2,000/yr)
- **Federal IRA Credit:** Up to $600 for high-efficiency A/C
- State-level rebates vary — check [EnergyStar.gov](https://www.energystar.gov/rebate-finder)

---

## 🌿 Tech Stack

- **HTML5** — semantic markup
- **CSS3** — custom properties, grid, flexbox, animations
- **Vanilla JS** — form handling, scroll events, intersection observer
- **Google Fonts** — Syne (display) + DM Sans (body)

---

## 📜 License

MIT — free to use, modify, and deploy for your business.

---

## 🏆 About GreenAire

Minority-owned and community-driven. Certified MBE. Specializing in electric heat pumps, solar-assisted HVAC, and ductless mini-split systems across the Southeast US.
